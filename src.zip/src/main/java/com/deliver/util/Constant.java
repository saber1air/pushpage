package com.deliver.util;

public interface Constant {
	String Code01 = "01";
	String Msg01 = "请求成功"; 
	String OrderByAddDateDesc = "ADDDATE DESC";
	String OrderByAddDateAsc = "ADDDATE ASC";
	String OrderByLikesDesc = "LIKES DESC";
	String OrderByBrowsesDesc = "BROWSES DESC";
	String OrderByCommentsDesc = "COMMENTS DESC";
	String OrderByScoreDesc = "SCORE DESC";
}
